from qf import main
main()

